import java.awt.*;
import java.awt.event.*;
import java.beans.*;


import gnu.io.*;
import java.io.*;

import com.topaz.sigplus.*;

public class SigPlusDemoLCD1x5 extends Frame implements Runnable
   {
   SigPlus              sigObj = null;
   static final int     numImages = 4;
   Image[]              rawImages;

   static final String  fileBase = "C:\\SigPlusJava2_45\\lcd1x5demo\\";
   Thread               eventThread;
   int                  page;
   boolean		start;
   String		signature;
	
   public static void main(String Args[])
      {
      SigPlusDemoLCD1x5 demo = new SigPlusDemoLCD1x5();
      }

   public SigPlusDemoLCD1x5()
      {
      int      i;
      String   fileName;

      try
         {

         ClassLoader cl = (com.topaz.sigplus.SigPlus.class).getClassLoader();
	      sigObj = (SigPlus)Beans.instantiate(cl, "com.topaz.sigplus.SigPlus");

	      setLayout( new GridLayout(1, 1));
  	      add(sigObj);
	      pack();
  	      setTitle("Topaz LCD 1X5 Demo");

         addWindowListener(new WindowAdapter()
            {
            public void windowClosing(WindowEvent we)
               {
               System.exit(0);
               }

            public void windowClosed(WindowEvent we)
               {
               System.exit(0);
               }
	    } );

         sigObj.addSigPlusListener(new SigPlusListener()
            {
            public void handleTabletTimerEvent(SigPlusEvent0 evt)
               {
               }

            public void handleNewTabletData(SigPlusEvent0 evt)
               {
               }

            public void handleKeyPadData(SigPlusEvent0 evt)
               {
               }
	   });

         setSize(600, 175);
         show();

         sigObj.setTabletModel("SignatureGemLCD1X5");
  	 sigObj.setTabletComPort("COM1");
         sigObj.setLCDCaptureMode(2);
	 sigObj.setTabletState(1);


         sigObj.setDisplayRotation(0);
         sigObj.setDisplayJustifyMode(1);
         sigObj.setDisplayJustifyX(50);
         sigObj.setDisplayJustifyY(50);
         //sigObj.setTimeStamp("August 16, 2002 14:12:00"); //Sets time stamp string
         //sigObj.setDisplayTimeStamp(true); //Displays time stamp
         //sigObj.setAnnotation("Topaz Java"); //Sets annotation string
         //sigObj.setDisplayAnnotation(true); //Displays annotation

	 sigObj.lcdSetWindow(0, 22, 240, 40);
	 sigObj.keyPadSetSigWindow(1, 0, 22, 240, 40);

         sigObj.keyPadAddHotSpot(0, 1, 195, 6, 19, 19);
	 sigObj.keyPadAddHotSpot(1, 1, 10, 4, 40, 17);
	 sigObj.keyPadAddHotSpot(2, 1, 28, 36, 32, 12);
	 sigObj.keyPadAddHotSpot(3, 1, 168, 37, 30, 12);

         MediaTracker mt = new MediaTracker(this);
         rawImages = new Image[ numImages ];
         String[] imageTitles = 
		{
			"ThankYou", 
			"Sign", 
			"Ok", 
			"Clear"
                };

	 for(i = 0; i < numImages; i++)
            {
               fileName = fileBase + imageTitles[i] + ".jpg";
               rawImages[ i ] = Toolkit.getDefaultToolkit().getImage(fileName);
               mt.addImage(rawImages[ i ], i + 1);
            }
         try
            {
               mt.waitForAll();
            }
         catch(Exception e)
            {
               System.out.println("Error opening bitmap files");
            }

         sigObj.lcdRefresh(0, 0, 0, 240, 128);

         sigObj.lcdWriteImage (1, 2, 0, 0, 240, 53, rawImages[0]);
         sigObj.lcdWriteImage (0, 2, 0, 20, 240, 44, rawImages[1]);
         sigObj.lcdWriteImage (0, 2, 207, 4, 21, 11, rawImages[2]);
         sigObj.lcdWriteImage (0, 2, 15, 4, 37, 11, rawImages[3]);
	 sigObj.lcdSetWindow(0, 22, 240, 40);
	 sigObj.keyPadSetSigWindow(1, 0, 22, 240, 40);
         page=1;

         
         eventThread = new Thread(this);
         eventThread.start();
         }
      catch (Exception e)
         {
         return;
         }
      }

   public void run()
      {
      try
	 {
	 while (true)
	    {
	    Thread.sleep(300);
            if(sigObj.keyPadQueryHotSpot(0) != 0 && page==1)
               {     
		     sigObj.keyPadClearSigWindow(1);     
                     sigObj.lcdRefresh(1, 210, 3, 14, 14);
		     signature=sigObj.getSigString(); //pass signature to "signature" variable
                     sigObj.clearTablet();
                     sigObj.keyPadClearSigWindow(1);
		     page=2;
		     sigObj.lcdSetWindow(0, 0, 0, 0);
	             sigObj.keyPadSetSigWindow(1, 0, 0, 0, 0);
		     sigObj.lcdRefresh(2, 0, 0, 240, 64);
               }
            else if(sigObj.keyPadQueryHotSpot(1) != 0 && page==1)
               {
                     sigObj.keyPadClearSigWindow(1);     
                     sigObj.clearTablet();
		     sigObj.lcdRefresh(1, 10, 0, 45, 17);
    		     sigObj.lcdRefresh(0, 0, 18, 240, 50);
    	 	     sigObj.lcdWriteImage(0, 2, 0, 20, 240, 44, rawImages[1]);
    		     sigObj.lcdRefresh(1, 10, 0, 45, 17);
                     sigObj.keyPadClearSigWindow(1);
               }
            else if(sigObj.keyPadQueryHotSpot(2) != 0 && page==2)
               {
                     sigObj.keyPadClearSigWindow(1);     
                     sigObj.clearTablet();
                     sigObj.lcdRefresh(1, 29, 38, 44, 19);
                     sigObj.keyPadClearSigWindow(1);
    		     sigObj.lcdRefresh(0, 0, 0, 240, 64);
    		     page = 1;
	             sigObj.keyPadSetSigWindow(1, 0, 22, 240, 40);
    		     sigObj.lcdSetWindow(0, 22, 240, 40);
            	     sigObj.lcdWriteImage (0, 2, 0, 20, 240, 44, rawImages[1]);
            	     sigObj.lcdWriteImage (0, 2, 207, 4, 21, 11, rawImages[2]);			                          sigObj.lcdWriteImage (0, 2, 15, 4, 37, 11, rawImages[3]);
                     sigObj.clearTablet();
               }
            else if(sigObj.keyPadQueryHotSpot(3) != 0 && page==2)
               {
                     sigObj.keyPadClearSigWindow(1);     
                     sigObj.clearTablet();
		     sigObj.lcdRefresh(1, 182, 37, 30, 19);
                     sigObj.keyPadClearSigWindow(1);
 		     sigObj.setTabletState(1);
    		     sigObj.setLCDCaptureMode(1);
    		     sigObj.lcdRefresh(0, 0, 0, 240, 64);
    		     sigObj.setTabletState(0);
		     System.exit(0);
               }
            
             sigObj.keyPadClearSigWindow(1);     
             }
	  }
      catch (InterruptedException e)
        {
	}
      }

   }


