#include "SigUsb.h"
#include <stdio.h>
#pragma optimize( "", off )
#pragma warning(disable : 4748) 


#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>

#include <SigLib.h>



//#define	LogSigUsb

//#define	DebugSigUsb
//#define	DebugSigUsbBuffers

#define	SigUsbClassPath	"com/topaz/sigplus/util/SigUsb"


bool            HidTablet = false;
TabletInterface* Tablet;



#ifdef	LogSigUsb

static FILE*	InputLog;
static FILE*	OutputLog;

#endif


void					
LogMessage( int OneForOutput, char* Str )
	{
#ifdef	LogSigUsb
	if ( OneForOutput == 1 )
		{
		fprintf( OutputLog, Str );
		fflush( OutputLog );
		//printf( "SigUsb:  Outputing %s\n", Str );
		}
	else
		{
		fprintf( InputLog, Str );
		fflush( InputLog );
		//printf( "SigUsb:   Inputing %s\n", Str );
		}
#endif
	}




#ifdef __cplusplus
extern "C" {
#endif


	
JNIEXPORT jint JNICALL JNI_OnLoad( JavaVM* jvm, void* reserved )
	{
	JNIEnv*					env;
	JNINativeMethod		nm[ 5 ];
	jclass					cls;

#ifdef	LogSigUsb
	InputLog = fopen( "SigUsbInputLog.dat", "a" );
	OutputLog = fopen( "SigUsbOutputLog.dat", "a" );
#endif

	if ( jvm->GetEnv( (void**)&env, JNI_VERSION_1_2 ) )
		{
		printf( "Unble to get env\n" );
		return JNI_ERR;
		}

	cls = env->FindClass( SigUsbClassPath );
	if ( cls == NULL )
		{
		printf( "Unable to locate class\n" );
		return JNI_ERR;
		}

	nm[ 0 ].name = "openUsbPort";
	nm[ 0 ].signature = "(Ljava/lang/String;)Z";
	nm[ 0 ].fnPtr = (void*)Java_SigUsb_openUsbPort;

	nm[ 1 ].name = "closeUsbPort";
	nm[ 1 ].signature = "()Z";
	nm[ 1 ].fnPtr = (void*)Java_SigUsb_closeUsbPort;

	nm[ 2 ].name = "getPointData";
	nm[ 2 ].signature = "()J";
	nm[ 2 ].fnPtr = (void*)Java_SigUsb_getPointData;

	nm[ 3 ].name = "putCmdString";
	nm[ 3 ].signature = "([B)Z";
	nm[ 3 ].fnPtr = (void*)Java_SigUsb_putCmdString;

	nm[ 4 ].name = "getSerialData";
	nm[ 4 ].signature = "()[B";
	nm[ 4 ].fnPtr = (void*)Java_SigUsb_getSerialData;
	env->RegisterNatives( cls, nm, 5 );

#ifdef	DebugSigUsb
	printf( "In JNI_OnLoad\n" );
#endif

	Tablet = NULL;
	return JNI_VERSION_1_2;
	}



JNIEXPORT jboolean JNICALL 
Java_SigUsb_openUsbPort(JNIEnv * Env, jobject, jstring Port)

	{
	jboolean	Value = false;
	jsize		PortNameLength;
	char*		PortName;
	int		InstanceToUse = 0;
	char		Tmp[ 16 ];

	if ( Tablet != NULL )
	  {
	  return true;
          }
	
	Tablet = new TabletInterface();
	//		Tablet->TabletParams.EnableLogging = true;
	if( strlen( Tablet->TabletParams.TabletPortPath ) == 0 )
	  {
	    strcpy( Tablet->TabletParams.TabletPortPath, "/dev" );
	  }

	PortNameLength = Env->GetStringUTFLength( Port );
	PortName = new char[ PortNameLength + 1 ];
	Env->GetStringUTFRegion( Port, 0, PortNameLength, PortName );
	
	if ( strlen( PortName ) > 3 )
		{
		strcpy( Tmp, &PortName[ 3 ] );
		sscanf( Tmp, "%d", &InstanceToUse );
		InstanceToUse--;
		}

	if ( strncmp( PortName, "HID", 3 ) == 0 )
	        {
		HidTablet = true;
		Tablet->TabletParams.TabletMode = HidSerialTabletType;
		}
	else
	  {
	    Tablet->TabletParams.TabletMode = UsbTabletType;
	  }

	Value = Tablet->OpenTabletRaw();

#ifdef	DebugSigUsb
	char	Msg[ 256 ];
	sprintf( Msg, "openUsbPort returns %d", Value );
	LogMessage( Msg );
#endif

	delete PortName;
	
	return Value;
	}







JNIEXPORT jboolean JNICALL 
Java_SigUsb_closeUsbPort(JNIEnv *, jobject)

	{
	if ( Tablet == NULL )
	  {
	  return false;
	  }
	Tablet->CloseTabletRaw();
	delete Tablet;
	Tablet = NULL;

#ifdef	DebugSigUsb
	LogMessage( "closeUsbPort" );
#endif
	return true;
	}







JNIEXPORT jlong JNICALL 
Java_SigUsb_getPointData(JNIEnv *, jobject)

	{
	jlong	Value = 0;

	if ( Tablet == NULL )
	  {
	  return 0;
	  }
	Value = Tablet->GetTabletData( 10 );
	if ( Value == GET_DATA_TIMED_OUT )
	  {
	    return 0;
	  }
	else
	  {
#ifdef	DebugSigUsb
		char	Msg[ 256 ];
		sprintf( Msg, "getPointData returning %08lx", Value );
		LogMessage( Msg );
#endif
	    return Value;
	  }

	}








JNIEXPORT jboolean JNICALL 
Java_SigUsb_putCmdString(JNIEnv * Env, jobject, jbyteArray Data )

	{
	jint		Length = Env->GetArrayLength( Data );
	jbyte*	Buffer = (jbyte*)malloc( Length );
	jboolean	Value = false;


#ifdef	DebugSigUsb
	char	Msg[ 256 ];
	sprintf( Msg, "putCmdString Tablet = %08lx, moving %d bytes", (long)Tablet, Length );
	LogMessage( Msg );
#endif
	if ( Tablet == NULL )
	  {
          return false;
	  }
	if ( HidTablet == true )
		{
		Env->GetByteArrayRegion( Data, 0, Length, Buffer );

		Tablet->PutTabletData( (unsigned char*)Buffer, Length );

		free( Buffer );
		}
#ifdef	DebugSigUsb
	sprintf( Msg, "putCmdString returning %0d", Value );
	LogMessage( Msg );
#endif

	return Value;
	}


JNIEXPORT jbyteArray JNICALL 
Java_SigUsb_getSerialData(JNIEnv * Env, jobject)

	{
	  if ( Tablet == NULL )
	    {
	    return NULL;
	    }
	  if ( HidTablet == true )
		{
		jbyte*		Buffer;
		int			BytesInBuffer;
		int			i;


		BytesInBuffer = Tablet->CircBuff->BytesInCircularBuffer();
		Buffer = (jbyte*)new char[ BytesInBuffer ];
		if ( Buffer == NULL )
			{
#ifdef	DebugSigUsb
			LogMessage( "N" );
#endif
			return NULL;
			}
		for( i = 0; i < BytesInBuffer; i++ )
			{
			Buffer[ i ] = Tablet->CircBuff->GetFromCircularBuffer();
#ifdef	LogSigUsb
			char	Str[ 256 ];
			
			sprintf( Str, "%02x ", Buffer[ i ] & 0xff );
			LogMessage( 1, Str );
#endif
			}

		jbyteArray	Data = Env->NewByteArray( BytesInBuffer );
		Env->SetByteArrayRegion( Data, 0, BytesInBuffer, Buffer );

#ifdef	DebugSigUsb
		char Msg[ 256 ];
		sprintf( Msg, "Returning %d bytes to Java", BytesInBuffer );
		LogMessage( Msg );
#endif

		delete Buffer;

#ifdef	DebugSigUsb
	LogMessage( "D" );
#endif
		return Data;
		}
	else
		{
#ifdef	DebugSigUsb
	LogMessage( "getSerialData returning NULL #3" );
#endif
		return NULL;
		}
	}




#pragma optimize( "", on ) 

#ifdef __cplusplus
}
#endif



















