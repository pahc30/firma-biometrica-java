export SIGUSB=/Volumes/Usr/Work/JavaUsb/MacOSX
export SIGLIB=/Volumes/Usr/Src/SigLib/MacOSX
