import java.awt.*;
import java.awt.event.*;
import java.beans.*;

import gnu.io.*;
import java.io.*;

import com.topaz.sigplus.*;

public class SigPlusDemoLCD extends Frame implements Runnable
   {
   SigPlus              sigObj = null;
   static final int     numImages = 8;
   Image[]              rawImages;

   static final String  fileBase = "/sigplusjava/lcd4x3/"; //change as necessary
   int			AppScreen;
   Thread               eventThread;
   int                  currentImage;	
   int                  page;
   String		signature;
	
   public static void main(String Args[])
      {
      SigPlusDemoLCD demo = new SigPlusDemoLCD();
      }

   public SigPlusDemoLCD()
      {
      int      i;
      String   fileName;

      try
         {

              ClassLoader cl = (com.topaz.sigplus.SigPlus.class).getClassLoader();
	      sigObj = (SigPlus)Beans.instantiate(cl, "com.topaz.sigplus.SigPlus");

	      setLayout(new GridLayout(1,1));
  	      add( sigObj );
	      pack();
  	      setTitle("Topaz LCD 4X3 Demo");


         addWindowListener(new WindowAdapter()
            {
            public void windowClosing(WindowEvent we)
               {
               System.exit(0);
               }

            public void windowClosed(WindowEvent we)
               {
               System.exit(0);
               }
	    });


         sigObj.addSigPlusListener(new SigPlusListener()
            {
            public void handleTabletTimerEvent(SigPlusEvent0 evt)
               {
               }

            public void handleNewTabletData(SigPlusEvent0 evt)
               {
               }


            public void handleKeyPadData(SigPlusEvent0 evt)
               {
               }
	    });

         setSize(640, 256);
         show();

         sigObj.setTabletModel("SignatureGemLCD4X3New");
  	 sigObj.setTabletComPort("/dev/ttyS0");
         sigObj.setLCDCaptureMode(2);
	 sigObj.setTabletState(1);

	 sigObj.setTabletComPort("/dev/ttyS0"); //change as necessary
         sigObj.setDisplayRotation(0);
         sigObj.setDisplayJustifyMode(1);
         sigObj.setDisplayJustifyX(50);
         sigObj.setDisplayJustifyY(50);

         sigObj.keyPadSetSigWindow(1, 0, 0, 0, 0);
         sigObj.lcdSetWindow(0,0,0,0);

         sigObj.keyPadAddHotSpot(0, 1, 11, 55, 15, 25);
	 sigObj.keyPadAddHotSpot(1, 1, 11, 75, 15, 25);
	 sigObj.keyPadAddHotSpot(2, 1, 70, 95, 30, 30);
	 sigObj.keyPadAddHotSpot(3, 1, 132, 95, 40, 30);
	 sigObj.keyPadAddHotSpot(4, 1, 18, 53, 59, 15);
	 sigObj.keyPadAddHotSpot(5, 1, 106, 52, 40, 16);
	 sigObj.keyPadAddHotSpot(6, 1, 186, 53, 35, 15);

         MediaTracker mt = new MediaTracker(this);
         rawImages = new Image[ numImages ];
         String[] imageTitles = 
		{
			"check", 
			"checkboxes", 
			"next_clear", 
			"please", 
			"prescription", 
			"screen1", 
			"Screen2", 
			"thanks"
                };


	 for(i = 0; i < numImages; i++)
            {
               fileName = fileBase + imageTitles[i] + ".jpg";
               rawImages[ i ] = Toolkit.getDefaultToolkit().getImage(fileName);
               mt.addImage(rawImages[ i ], i + 1);
            }

         try
            {
            mt.waitForAll();
            }
         catch(Exception e)
            {
            System.out.println("Error opening bitmap files");
            }

         sigObj.lcdRefresh(0, 0, 0, 240, 128);

         sigObj.lcdWriteImage (1, 2, 0, 0, 240, 128, rawImages[6]);
         sigObj.lcdWriteImage (0, 2, 10, 0, 100, 10, rawImages[4]);
         sigObj.lcdWriteImage (0, 2, 10, 64, 130, 40, rawImages[1]);
         sigObj.lcdWriteImage (0, 2, 70, 110, 100, 10, rawImages[2]);
         page=1;

         
         eventThread = new Thread(this);
         eventThread.start();
         }
      catch (Exception e)
         {
         return;
         }
      }

   public void run()
      {
      try
	 {
	 while (true)
	    {
	    Thread.sleep(100);
            
            if(sigObj.keyPadQueryHotSpot(0) !=0 && page==1)
               {
                     sigObj.clearTablet();
                     sigObj.keyPadClearSigWindow(1);
                     sigObj.lcdWriteImage(0, 3, 12, 65, 14, 13, rawImages[0]);
               }
            else if(sigObj.keyPadQueryHotSpot(1) !=0 && page==1)
               {
                     sigObj.clearTablet();
                     sigObj.keyPadClearSigWindow(1);
    		     sigObj.lcdWriteImage(0, 3, 12, 88, 14, 13, rawImages[0]);
               }
            else if(sigObj.keyPadQueryHotSpot(2) !=0 && page==1)
               {
                     sigObj.clearTablet();
                     sigObj.keyPadClearSigWindow(1);
    		     sigObj.lcdRefresh(1, 70, 110, 30, 15);
    		     sigObj.lcdRefresh(2, 0, 0, 240, 128);
    		     sigObj.lcdSetWindow(0, 74, 240, 118);
                     sigObj.keyPadSetSigWindow(1, 0, 74, 240, 118);
    		     page = 2;
               }
            else if(sigObj.keyPadQueryHotSpot(3) !=0 && page==1)
               {
                     sigObj.clearTablet();
                     sigObj.keyPadClearSigWindow(1);
    		     sigObj.lcdRefresh(1, 132, 110, 40, 15);
    		     sigObj.lcdWriteImage(0, 2, 10, 64, 130, 40, rawImages[1]);
                     Thread.sleep(300);
                     sigObj.keyPadClearSigWindow(1);
    		     sigObj.lcdRefresh(1, 132, 110, 40, 15);
               }
            else if(sigObj.keyPadQueryHotSpot(4) !=0 && page==2)
               {
                     sigObj.clearTablet();
                     sigObj.keyPadClearSigWindow( 1 );
    		     sigObj.lcdRefresh(1, 18, 53, 58, 15);
    		     sigObj.lcdRefresh(0, 0, 0, 240, 128);
                     sigObj.lcdWriteImage (0, 2, 10, 0, 100, 10, rawImages[4]);
         	     sigObj.lcdWriteImage (0, 2, 10, 64, 130, 40, rawImages[1]);
         	     sigObj.lcdWriteImage (0, 2, 70, 110, 100, 10, rawImages[2]);
    		     sigObj.lcdSetWindow(0, 0, 0, 0);
                     sigObj.keyPadSetSigWindow(1, 0, 0, 0, 0 );
                     page=1;
               }
            else if(sigObj.keyPadQueryHotSpot(5) !=0 && page==2)
               {
                     sigObj.clearTablet();
                     sigObj.keyPadClearSigWindow(1);
    		     sigObj.lcdRefresh(1, 106, 52, 40, 16);
                     Thread.sleep(300);
                     sigObj.keyPadClearSigWindow(1);
    		     sigObj.lcdRefresh(2, 0, 0, 240, 128);
   		     sigObj.keyPadSetSigWindow(1, 0, 74, 240, 118);

               }
            else if(sigObj.keyPadQueryHotSpot(6) !=0 && page==2)
               {
                     sigObj.lcdRefresh(1, 186, 53, 35, 15);

                     if( sigObj.numberOfTabletPoints() > 0)
                        {
                           sigObj.lcdRefresh(0, 0, 0, 240, 128);
                           signature = sigObj.getSigString(); //signature variable gets sig data
                           sigObj.clearTablet(); 
                           sigObj.keyPadClearSigWindow(1); 
       			   sigObj.lcdWriteImage(0, 2, 3, 46, 233, 24, rawImages[7]);
                           sigObj.setTabletState(1);
			   sigObj.lcdRefresh(0, 0, 0, 240, 128);
                           sigObj.setLCDCaptureMode(1);
                           sigObj.setTabletState(0);
                           System.exit(0);
                        }
    		     else
                        {
       			   sigObj.lcdRefresh(0, 0, 0, 240, 128);
                           sigObj.clearTablet();  
                           sigObj.keyPadClearSigWindow(1);
       			   sigObj.lcdWriteImage( 0, 2, 4, 46, 234, 20, rawImages[3]);
       			   sigObj.lcdRefresh(0, 0, 0, 240, 128);
    		     	   sigObj.lcdRefresh(2, 0, 0, 240, 128);
    		           sigObj.lcdSetWindow(0, 74, 240, 118);
                           sigObj.keyPadSetSigWindow(1, 0, 74, 240, 118);
    		           page = 2;
       			   //Start over again
			}
                     sigObj.keyPadClearSigWindow(1);
                     sigObj.clearTablet();
                  }
                }
	      }
      catch (InterruptedException e)
         {
	 }
      }

   }


