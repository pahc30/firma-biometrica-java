import java.awt.*;
import java.awt.event.*;
import java.beans.*;

import gnu.io.*;
import java.io.*;

import com.topaz.sigplus.*;

public class SigPlusColorPinPadDemo extends Frame implements Runnable
   {
   SigPlus              sigObj = null;
   static final int     numImages = 3;
   Image[]              rawImages;

   static final String  fileBase = ".\\";
   Thread               eventThread;
   String		signature;
   String		padVal="";
	
   public static void main(String Args[])
      {
      SigPlusColorPinPadDemo demo = new SigPlusColorPinPadDemo();
      }

   public SigPlusColorPinPadDemo()
      {
      int      i;
      String   fileName;


      try
         {

              ClassLoader cl = (com.topaz.sigplus.SigPlus.class).getClassLoader();
	      sigObj = (SigPlus)Beans.instantiate(cl, "com.topaz.sigplus.SigPlus");

	      setLayout(new GridLayout(1,1));
  	      add( sigObj );
	      pack();
  	      setTitle("Topaz SigGem Color 5.7 Demo");


         addWindowListener(new WindowAdapter()
            {
            public void windowClosing(WindowEvent we)
               {
                  try{
                  //reset hardware to default settings
                  sigObj.lcdRefresh(0, 0, 0, 640, 480);
                  sigObj.keyPadClearHotSpotList();
                  sigObj.keyPadSetSigWindow(1, 0, 0, 640, 480);
                  sigObj.lcdSetWindow(0, 0, 640, 480);
                  sigObj.lcdWriteImage(1, 0, 0, 0, 640, 480, rawImages[0], 0); //clear background memory
                  sigObj.setLCDCaptureMode(1);
                  sigObj.setTabletState(0);
                  System.exit(0);
                  }
                  catch(Exception e)
                  {
                     //let it go
                  }
               }

            public void windowClosed(WindowEvent we)
               {
                  System.exit(0);
               }
	    });


         sigObj.addSigPlusListener(new SigPlusListener()
            {
            public void handleTabletTimerEvent(SigPlusEvent0 evt)
               {
               }

            public void handleNewTabletData(SigPlusEvent0 evt)
               {
               }


            public void handleKeyPadData(SigPlusEvent0 evt)
               {
               }
	    });

         setSize(640, 256);
         show();

         sigObj.setTabletModel("SigGemColor57");
  	 sigObj.setTabletComPort("HID1");
  	 sigObj.setTabletBaudRate(115200);

         //check for pad connectivity
	 sigObj.setTabletComTest(true);
	 sigObj.setTabletState(1);

         if(sigObj.getTabletState()==0)
         {
            sigObj.setTabletComTest(false);
            System.out.println("Cannot locate signature pad...exiting");
            System.exit(0);
         }
      

         sigObj.setTabletComTest(false);
         sigObj.setLCDCaptureMode(2);

         sigObj.keyPadSetSigWindow(1, 0, 0, 1, 1);
         sigObj.lcdSetWindow(0, 0, 1, 1);


         sigObj.keyPadAddHotSpot(0, 1, 24, 26, 92, 94); //1
         sigObj.keyPadAddHotSpot(1, 1, 132, 28, 92, 94); //2
         sigObj.keyPadAddHotSpot(2, 1, 248, 28, 88, 92); //3
         sigObj.keyPadAddHotSpot(3, 1, 26, 142, 88, 92); //4
         sigObj.keyPadAddHotSpot(4, 1, 134, 142, 90, 90); //5
         sigObj.keyPadAddHotSpot(5, 1, 246, 142, 90, 92); //6
         sigObj.keyPadAddHotSpot(6, 1, 24, 254, 92, 90); //7
         sigObj.keyPadAddHotSpot(7, 1, 136, 252, 88, 92); //8
         sigObj.keyPadAddHotSpot(8, 1, 246, 254, 92, 88); //9
         sigObj.keyPadAddHotSpot(9, 1, 138, 364, 86, 90); //0

         sigObj.keyPadAddHotSpot(10, 1, 24, 364, 86, 90); //CLEAR

         sigObj.keyPadAddHotSpot(11, 1, 246, 364, 86, 90); //DONE


         MediaTracker mt = new MediaTracker(this);
         rawImages = new Image[ numImages ];
         String[] imageTitles = 
		{
			"scpinpad", 
			"scclear",
                        "scdone"
                };

	 for(i = 0; i < numImages; i++)
            {
               fileName = fileBase + imageTitles[i] + ".jpg";
               rawImages[ i ] = Toolkit.getDefaultToolkit().getImage(fileName);
               mt.addImage(rawImages[ i ], i + 1);
            }
         try
            {
               mt.waitForAll();
            }
         catch(Exception e)
            {
               System.out.println("Error opening image files");
            }

         sigObj.lcdRefresh(0, 0, 0, 640, 480);


	 sigObj.setLCDPixelDepth(0);
	 sigObj.lcdWriteImage(1, 2, 28, 30, 308, 424, rawImages[0], 0);

         sigObj.setLCDPixelDepth(8);
	 sigObj.lcdWriteImage(1, 2, 28, 363, 87, 91, rawImages[1], 3);
	 sigObj.lcdWriteImage(1, 2, 250, 363, 87, 91, rawImages[2], 3);

	 sigObj.lcdRefresh(2, 0, 0, 640, 480);
	 sigObj.setLCDCaptureMode(2);

         
         eventThread = new Thread(this);
         eventThread.start();
         }
      catch (Exception e)
         {
         return;
         }
      }

   public void run()
      {
      try
	 {
	 while (true)
	    {
	    Thread.sleep(75);
            
            if(sigObj.keyPadQueryHotSpot(0) !=0)
               {
                     sigObj.keyPadClearSigWindow(1);
                     sigObj.lcdRefresh(1, 24, 26, 86, 94);
                     //1 HAS BEEN CHOSEN
                     padVal += "1";
		     sigObj.lcdRefresh(1, 24, 26, 86, 94);
               }

            if(sigObj.keyPadQueryHotSpot(1) !=0)
               {
                     sigObj.keyPadClearSigWindow(1);
                     sigObj.lcdRefresh(1, 132, 28, 86, 94);
                     //2 HAS BEEN CHOSEN
                     padVal += "2";
		     sigObj.lcdRefresh(1, 132, 28, 86, 94);
               }

            if(sigObj.keyPadQueryHotSpot(2) !=0)
               {
                     sigObj.keyPadClearSigWindow(1);
                     sigObj.lcdRefresh(1, 248, 28, 88, 92);
                     //3 HAS BEEN CHOSEN
                     padVal += "3";
		     sigObj.lcdRefresh(1, 248, 28, 88, 92);
               }

            if(sigObj.keyPadQueryHotSpot(3) !=0)
               {
                     sigObj.keyPadClearSigWindow(1);
                     sigObj.lcdRefresh(1, 26, 142, 88, 92);
                     //4 HAS BEEN CHOSEN
                     padVal += "4";
		     sigObj.lcdRefresh(1, 26, 142, 88, 92);
               }

            if(sigObj.keyPadQueryHotSpot(4) !=0)
               {
                     sigObj.keyPadClearSigWindow(1);
                     sigObj.lcdRefresh(1, 134, 142, 86, 90);
                     //5 HAS BEEN CHOSEN
                     padVal += "5";
		     sigObj.lcdRefresh(1, 134, 142, 86, 90);
               }

            if(sigObj.keyPadQueryHotSpot(5) !=0)
               {
                     sigObj.keyPadClearSigWindow(1);
                     sigObj.lcdRefresh(1, 246, 142, 86, 92);
                     //6 HAS BEEN CHOSEN
                     padVal += "6";
		     sigObj.lcdRefresh(1, 246, 142, 86, 92);
               }

            if(sigObj.keyPadQueryHotSpot(6) !=0)
               {
                     sigObj.keyPadClearSigWindow(1);
                     sigObj.lcdRefresh(1, 24, 254, 86, 90);
                     //7 HAS BEEN CHOSEN
                     padVal += "7";
		     sigObj.lcdRefresh(1, 24, 254, 86, 90);
               }

            if(sigObj.keyPadQueryHotSpot(7) !=0)
               {
                     sigObj.keyPadClearSigWindow(1);
                     sigObj.lcdRefresh(1, 136, 252, 88, 92);
                     //8 HAS BEEN CHOSEN
                     padVal += "8";
		     sigObj.lcdRefresh(1, 136, 252, 88, 92);
               }

            if(sigObj.keyPadQueryHotSpot(8) !=0)
               {
                     sigObj.keyPadClearSigWindow(1);
                     sigObj.lcdRefresh(1, 246, 254, 86, 88);
                     //9 HAS BEEN CHOSEN
                     padVal += "9";
		     sigObj.lcdRefresh(1, 246, 254, 86, 88);
               }

            if(sigObj.keyPadQueryHotSpot(9) !=0)
               {
                     sigObj.keyPadClearSigWindow(1);
                     sigObj.lcdRefresh(1, 138, 364, 86, 90);
                     //0 HAS BEEN CHOSEN
                     padVal += "0";
		     sigObj.lcdRefresh(1, 138, 364, 86, 90);
               }   


            if(sigObj.keyPadQueryHotSpot(10) !=0) //CLEAR
               {
                     sigObj.keyPadClearSigWindow(1);
                     sigObj.lcdRefresh(1, 24, 364, 86, 90);
                     //CLEAR HAS BEEN CHOSEN
                     padVal = "";
		     sigObj.lcdRefresh(1, 24, 364, 86, 90);
               } 



            if(sigObj.keyPadQueryHotSpot(11) !=0) //DONE
               {
                     sigObj.keyPadClearSigWindow(1);
                     sigObj.lcdRefresh(1, 246, 364, 86, 90);
                     //DONE HAS BEEN CHOSEN
                     System.out.println(padVal);
                     padVal = ""; //reset pinpad
		     sigObj.lcdRefresh(1, 246, 364, 86, 90);
               } 

             sigObj.keyPadClearSigWindow(1);
             }
           }
      catch (InterruptedException e)
         {
	 }
      }

   }


